"""
Convert CSV mapping files to Excel format for UNFI processors
"""
import pandas as pd
import os

def convert_csv_to_excel(csv_path, excel_path):
    """Convert CSV file to Excel format"""
    try:
        df = pd.read_csv(csv_path)
        df.to_excel(excel_path, index=False)
        print(f"✅ Converted {csv_path} to {excel_path}")
        return True
    except Exception as e:
        print(f"❌ Error converting {csv_path}: {e}")
        return False

def main():
    """Convert all CSV mapping files to Excel"""
    base_dir = os.path.dirname(__file__)
    
    # Files to convert
    conversions = [
        ("mappings/unfi_west/item_mapping.csv", "mappings/unfi_west/item_mapping.xlsx"),
        ("mappings/unfi_east/item_mapping.csv", "mappings/unfi_east/item_mapping.xlsx"),
        ("mappings/unfi_east/store_mapping.csv", "mappings/unfi_east/store_mapping.xlsx"),
    ]
    
    print("Converting CSV mapping files to Excel...")
    print("="*50)
    
    success_count = 0
    total_count = len(conversions)
    
    for csv_file, excel_file in conversions:
        csv_path = os.path.join(base_dir, csv_file)
        excel_path = os.path.join(base_dir, excel_file)
        
        if os.path.exists(csv_path):
            if convert_csv_to_excel(csv_path, excel_path):
                success_count += 1
        else:
            print(f"❌ Source file not found: {csv_path}")
    
    print(f"\nConversion completed: {success_count}/{total_count} files converted successfully")
    
    if success_count == total_count:
        print("✅ All files converted successfully!")
    else:
        print("⚠️  Some files failed to convert")

if __name__ == "__main__":
    main()
