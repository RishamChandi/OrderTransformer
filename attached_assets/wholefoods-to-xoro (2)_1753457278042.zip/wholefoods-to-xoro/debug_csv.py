#!/usr/bin/env python3
"""
Debug CSV parsing for UNFI
"""

import tempfile
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from app.order_sources import extract_order_data_unfi

# Create the same test CSV data as in the test
csv_data = """Order Number,12345
Order Date,01/20/2024
Customer,UNFI General Customer

Line,Item,Quantity,Description,Cost,UPC
1,11111,15,General Product 1,$12.99,333333333333
2,22222,20,General Product 2,$8.75,444444444444
3,33333,10,General Product 3,$25.00,555555555555
"""

# Write to temp file
temp_csv = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False)
temp_csv.write(csv_data)
temp_csv.close()

try:
    print("Testing CSV parsing...")
    print("=" * 40)
    print(f"Test file: {temp_csv.name}")
    print()
    
    # Parse the CSV
    result = extract_order_data_unfi(temp_csv.name)
    
    print("Result:")
    print(f"Metadata: {result['metadata']}")
    print(f"Line items count: {len(result['line_items'])}")
    print()
    
    if result['line_items']:
        print("First line item:")
        print(result['line_items'][0])
    else:
        print("No line items found!")
        
        # Debug: let's see what the parser is seeing
        import pandas as pd
        df = pd.read_csv(temp_csv.name, header=None, skip_blank_lines=False, engine='python')
        print("\nDebug - DataFrame content:")
        print(df)
        print(f"\nDataFrame shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
        
        # Check each row
        print("\nRow analysis:")
        for i in range(len(df)):
            row_text = ' '.join(str(df.iloc[i][col_idx]).lower() for col_idx in range(len(df.columns)) if col_idx < len(df.iloc[i]) and pd.notna(df.iloc[i].iloc[col_idx]))
            print(f"Row {i}: {row_text}")
            
            # Check for line item headers
            line_item_headers = ['item', 'product', 'sku', 'quantity', 'qty', 'description', 'cost', 'price', 'upc']
            header_matches = sum(1 for header in line_item_headers if header in row_text)
            print(f"  Header matches: {header_matches}")

finally:
    os.unlink(temp_csv.name)
