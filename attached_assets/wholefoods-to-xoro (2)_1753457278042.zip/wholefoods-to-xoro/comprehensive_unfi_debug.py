#!/usr/bin/env python3
"""
Comprehensive UNFI West file analyzer
"""

from bs4 import BeautifulSoup
import re
import os

def analyze_unfi_west_file(file_path):
    """
    Analyze UNFI West file comprehensively to understand its structure
    """
    print(f"Analyzing: {file_path}")
    print("=" * 60)
    
    if not os.path.exists(file_path):
        print(f"ERROR: File does not exist!")
        return None
    
    # Read with multiple encodings
    content = None
    successful_encoding = None
    
    encodings = ['cp1252', 'windows-1252', 'latin-1', 'utf-8', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            successful_encoding = encoding
            print(f"✓ Read successfully with: {encoding}")
            break
        except Exception as e:
            print(f"✗ Failed with {encoding}: {str(e)[:50]}...")
    
    if not content:
        print("Could not read file with any encoding!")
        return None
    
    print(f"File size: {len(content):,} characters")
    
    # Parse HTML
    soup = BeautifulSoup(content, 'html.parser')
    
    # Basic info
    print(f"\nHTML Title: {soup.title.string if soup.title else 'None'}")
    
    # Count elements
    tables = soup.find_all('table')
    divs = soup.find_all('div')
    spans = soup.find_all('span')
    
    print(f"Tables found: {len(tables)}")
    print(f"Divs found: {len(divs)}")
    print(f"Spans found: {len(spans)}")
    
    # Analyze tables
    for i, table in enumerate(tables):
        print(f"\n--- Table {i+1} ---")
        rows = table.find_all('tr')
        print(f"Rows: {len(rows)}")
        
        if rows:
            # First row (likely header)
            first_row = rows[0]
            cells = first_row.find_all(['td', 'th'])
            if cells:
                cell_texts = [cell.get_text(strip=True) for cell in cells]
                print(f"First row cells: {cell_texts}")
            
            # Sample data rows
            if len(rows) > 1:
                for j in range(1, min(4, len(rows))):
                    row = rows[j]
                    cells = row.find_all(['td', 'th'])
                    if cells:
                        cell_texts = [cell.get_text(strip=True) for cell in cells]
                        print(f"Row {j+1} cells: {cell_texts}")
    
    # Extract all text and look for patterns
    full_text = soup.get_text()
    
    print(f"\n--- Pattern Analysis ---")
    
    # Order numbers
    order_patterns = [
        r'Purchase\s+Order\s+(\d+)',
        r'Order\s+(\d+)',
        r'PO\s*#?\s*(\d+)',
        r'\b(\d{8,12})\b'  # Long numbers that might be order IDs
    ]
    
    for pattern in order_patterns:
        matches = re.findall(pattern, full_text, re.IGNORECASE)
        if matches:
            print(f"Order numbers ({pattern}): {matches[:5]}")
    
    # Dates
    date_patterns = [
        r'\d{2}/\d{2}/\d{4}',
        r'\d{2}/\d{2}/\d{2}',
        r'\d{4}-\d{2}-\d{2}'
    ]
    
    for pattern in date_patterns:
        matches = re.findall(pattern, full_text)
        if matches:
            print(f"Dates ({pattern}): {matches[:5]}")
    
    # UNFI references
    unfi_refs = re.findall(r'UNFI[^\\n\\r]{0,30}', full_text, re.IGNORECASE)
    if unfi_refs:
        print(f"UNFI references: {unfi_refs[:3]}")
    
    # Look for item-like patterns
    item_patterns = [
        r'\\b\\d{4,8}\\b',  # Item numbers
        r'\\b[A-Z]{2,5}\\d{3,8}\\b'  # Alpha-numeric codes
    ]
    
    for pattern in item_patterns:
        matches = re.findall(pattern, full_text)
        if matches:
            print(f"Potential items ({pattern}): {matches[:10]}")
    
    # Show first 1000 characters of text
    print(f"\n--- First 1000 characters of text ---")
    print(full_text[:1000])
    print("..." if len(full_text) > 1000 else "")
    
    return soup, content

def test_parser_with_file(file_path):
    """Test the actual parser"""
    print(f"\n{'='*60}")
    print("TESTING ACTUAL PARSER")
    print(f"{'='*60}")
    
    try:
        from unfi_west_transformer import extract_order_data_unfi_west
        result = extract_order_data_unfi_west(file_path)
        
        print(f"Metadata extracted: {result['metadata']}")
        print(f"Line items found: {len(result['line_items'])}")
        
        if result['line_items']:
            print("\\nFirst few items:")
            for i, item in enumerate(result['line_items'][:3]):
                print(f"  {i+1}: {item}")
        
        return result
        
    except Exception as e:
        print(f"Parser error: {e}")
        import traceback
        traceback.print_exc()
        return None

if __name__ == "__main__":
    file_path = r"c:\\Users\\risha\\Downloads\\UNFI WEST Purchase Order 446758464 08_30_24.html"
    
    # Analyze the file structure
    soup, content = analyze_unfi_west_file(file_path)
    
    # Test the parser
    if soup:
        test_parser_with_file(file_path)
