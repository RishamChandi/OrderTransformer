#!/usr/bin/env python3
"""
Quick app functionality test
Tests all UNFI processors without running the full Streamlit app
"""

import sys
import os

# Add current directory to path
sys.path.append(os.path.dirname(__file__))

from app.order_sources import ORDER_SOURCES
from generator import build_xoro_row, save_to_csv
from mapper import load_mappings

def test_app_functionality():
    """Test the core app functionality with sample files"""
    print("🧪 TESTING APP FUNCTIONALITY")
    print("=" * 50)
    
    # Test files
    test_files = {
        "UNFI West": "test_files/unfi_west_sample.html",
        "UNFI East": "test_files/unfi_east_sample.html", 
        "UNFI": "test_files/unfi_general_sample.csv"
    }
    
    base_template = "templates/base_xoro_template.csv"
    
    # Load template columns
    if os.path.exists(base_template):
        with open(base_template, 'r', encoding='utf-8') as f:
            template_columns = f.readline().strip().split(',')
    else:
        # Use default columns if template doesn't exist
        template_columns = [
            '**DateToBeShipped', '**OrderDate', '**ItemNumber', 'ItemNotes',
            '**UnitPrice', '**Qty', '**CurrencyCode', '**ExchangeRate',
            '**CustomerName', '**SaleStoreName', 'StoreName', 'ThirdPartyRefNo',
            'RefNo', 'CustomerPO', 'SalesRepId', 'CustomFieldD1'
        ]
    
    all_results = {}
    
    for source_name, test_file in test_files.items():
        print(f"\n📋 Testing {source_name}")
        print("-" * 30)
        
        if not os.path.exists(test_file):
            print(f"❌ Test file not found: {test_file}")
            continue
            
        try:
            # Get source configuration
            config = ORDER_SOURCES[source_name]
            parser = config["parser"]
            
            # Parse order data
            print(f"✅ Parsing {test_file}")
            order_data = parser(test_file)
            
            print(f"   Metadata: {order_data['metadata']}")
            print(f"   Line items: {len(order_data['line_items'])}")
            
            if order_data['line_items']:
                print(f"   First item: {order_data['line_items'][0]['item_no']} - {order_data['line_items'][0]['description']}")
            
            # Test mapping (if files exist)
            item_mapping_file = config["item_mapping"]
            store_mapping_file = config["store_mapping"]
            
            if os.path.exists(item_mapping_file) and os.path.exists(store_mapping_file):
                print(f"✅ Loading mappings")
                item_mapping_df, store_mapping_df = load_mappings(item_mapping_file, store_mapping_file)
                
                # Test Xoro row generation
                if order_data['line_items']:
                    print(f"✅ Generating Xoro rows")
                    xoro_rows = []
                    for line_item in order_data['line_items']:
                        row = build_xoro_row(
                            order_data,
                            line_item,
                            item_mapping_df,
                            store_mapping_df,
                            template_columns
                        )
                        xoro_rows.append(row)
                    
                    print(f"   Generated {len(xoro_rows)} Xoro rows")
                    
                    # Save test output
                    output_file = f"test_output_{source_name.lower().replace(' ', '_')}.csv"
                    save_to_csv(xoro_rows, output_file)
                    print(f"✅ Saved output to: {output_file}")
                    
                    all_results[source_name] = {
                        "status": "success",
                        "line_items": len(order_data['line_items']),
                        "xoro_rows": len(xoro_rows),
                        "output_file": output_file
                    }
            else:
                print(f"⚠️  Mapping files not found - testing parser only")
                all_results[source_name] = {
                    "status": "partial",
                    "line_items": len(order_data['line_items']),
                    "note": "Mapping files missing"
                }
                
        except Exception as e:
            print(f"❌ Error testing {source_name}: {e}")
            all_results[source_name] = {
                "status": "failed",
                "error": str(e)
            }
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST SUMMARY")
    print("=" * 50)
    
    for source, result in all_results.items():
        status_icon = "✅" if result["status"] == "success" else "⚠️" if result["status"] == "partial" else "❌"
        print(f"{status_icon} {source}: {result['status']}")
        if "line_items" in result:
            print(f"   Line items processed: {result['line_items']}")
        if "xoro_rows" in result:
            print(f"   Xoro rows generated: {result['xoro_rows']}")
        if "output_file" in result:
            print(f"   Output saved: {result['output_file']}")
        if "error" in result:
            print(f"   Error: {result['error']}")
    
    success_count = sum(1 for r in all_results.values() if r["status"] == "success")
    total_count = len(all_results)
    
    print(f"\nOverall: {success_count}/{total_count} sources working perfectly")
    
    if success_count == total_count:
        print("🎉 ALL TESTS PASSED - App is ready for use!")
    else:
        print("⚠️  Some issues found - check above for details")

if __name__ == "__main__":
    test_app_functionality()
