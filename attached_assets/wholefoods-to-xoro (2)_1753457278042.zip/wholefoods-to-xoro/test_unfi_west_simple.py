#!/usr/bin/env python3
"""
Simple test for UNFI West parser
"""

import sys
import os

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from unfi_west_transformer import extract_order_data_unfi_west

def test_unfi_west():
    file_path = r"c:\Users\risha\Downloads\UNFI WEST Purchase Order 446758464 08_30_24.html"
    
    print("Testing UNFI West parser...")
    print(f"File: {file_path}")
    
    try:
        result = extract_order_data_unfi_west(file_path)
        
        print("\n=== RESULTS ===")
        print(f"Metadata: {result['metadata']}")
        print(f"Number of line items: {len(result['line_items'])}")
        
        if result['line_items']:
            print("\nFirst few line items:")
            for i, item in enumerate(result['line_items'][:3]):
                print(f"  Item {i+1}: {item}")
        else:
            print("No line items found!")
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_unfi_west()
