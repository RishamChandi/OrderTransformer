#!/usr/bin/env python3
"""
Test UNFI West implementation specifically
"""

import tempfile
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from unfi_west_transformer import extract_order_data_unfi_west, transform_unfi_west_order
from app.order_sources import ORDER_SOURCES

# Create test HTML for UNFI West
unfi_west_html = """
<html>
    <body>
        <div>UNFI - West Coast Distribution Center</div>
        <div>Order Date: 12/15/2023</div>
        <div>Order #WC12345</div>
        <table>
            <tr>
                <th>Line</th>
                <th>Item No.</th>
                <th>Qty</th>
                <th>Description</th>
                <th>Size</th>
                <th>Cost</th>
                <th>UPC</th>
            </tr>
            <tr>
                <td>1</td>
                <td>12345</td>
                <td>10</td>
                <td>West Coast Product 1</td>
                <td>24/12oz</td>
                <td>$15.99</td>
                <td>123456789012</td>
            </tr>
            <tr>
                <td>2</td>
                <td>67890</td>
                <td>5</td>
                <td>West Coast Product 2</td>
                <td>12/16oz</td>
                <td>$22.50</td>
                <td>987654321098</td>
            </tr>
        </table>
    </body>
</html>
"""

def test_unfi_west_wrapper():
    """Test the new UNFI West wrapper function"""
    print("Testing UNFI West Wrapper Function")
    print("=" * 40)
    
    # Create temp file
    temp_html = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
    temp_html.write(unfi_west_html)
    temp_html.close()
    
    try:
        # Test the new wrapper function
        result = extract_order_data_unfi_west(temp_html.name)
        
        print("Result structure:")
        print(f"✅ Has metadata: {'metadata' in result}")
        print(f"✅ Has line_items: {'line_items' in result}")
        
        print(f"\nMetadata: {result['metadata']}")
        print(f"Line items count: {len(result['line_items'])}")
        
        if result['line_items']:
            print("\nFirst line item:")
            print(result['line_items'][0])
        
        # Test that it works with ORDER_SOURCES
        parser = ORDER_SOURCES["UNFI West"]["parser"]
        result2 = parser(temp_html.name)
        
        print(f"\n✅ ORDER_SOURCES integration: {'metadata' in result2 and 'line_items' in result2}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False
    finally:
        os.unlink(temp_html.name)

def test_unfi_west_original():
    """Test the original transform function"""
    print("\nTesting Original UNFI West Transform Function")
    print("=" * 50)
    
    # Create temp files
    temp_html = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
    temp_html.write(unfi_west_html)
    temp_html.close()
    
    # Create dummy mapping and template files
    import pandas as pd
    
    # Store mapping
    store_mapping = pd.DataFrame({
        'UNFI Customer Name': ['UNFI - West Coast Distribution Center'],
        'Xoro Customer Name': ['West Coast Customer']
    })
    temp_store = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
    store_mapping.to_excel(temp_store.name, index=False)
    temp_store.close()
    
    # Template
    template_data = "CustomerName,OrderDate,ItemCode,Quantity,Description\n"
    temp_template = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False)
    temp_template.write(template_data)
    temp_template.close()
    
    try:
        # Test original function
        result = transform_unfi_west_order(
            temp_html.name,
            temp_store.name,
            temp_template.name
        )
        
        print(f"✅ Original function works: {result is not None}")
        print(f"✅ Returns DataFrame: {hasattr(result, 'shape')}")
        if hasattr(result, 'shape'):
            print(f"DataFrame shape: {result.shape}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error in original function: {e}")
        return False
    finally:
        os.unlink(temp_html.name)
        os.unlink(temp_store.name)
        os.unlink(temp_template.name)

def main():
    print("🔍 UNFI WEST IMPLEMENTATION TEST")
    print("=" * 50)
    
    success1 = test_unfi_west_wrapper()
    success2 = test_unfi_west_original()
    
    print("\n" + "=" * 50)
    if success1 and success2:
        print("✅ UNFI West is FULLY IMPLEMENTED and working!")
    else:
        print("❌ UNFI West has issues that need fixing")
    
    print("=" * 50)

if __name__ == "__main__":
    main()
