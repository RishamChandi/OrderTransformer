#!/usr/bin/env python3
"""
Debug script for UNFI West parser issues
"""

import sys
import os
from bs4 import BeautifulSoup
import re

def debug_unfi_west_file(file_path):
    """Debug the UNFI West HTML file to see what's inside"""
    
    print(f"Analyzing file: {file_path}")
    print("=" * 50)
    
    # Check if file exists
    if not os.path.exists(file_path):
        print(f"ERROR: File does not exist: {file_path}")
        return
    
    # Try different encodings
    content = None
    encodings_to_try = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1', 'utf-16']
    
    for encoding in encodings_to_try:
        try:
            with open(file_path, encoding=encoding) as f:
                content = f.read()
            print(f"✓ Successfully read with encoding: {encoding}")
            break
        except UnicodeDecodeError as e:
            print(f"✗ Failed with {encoding}: {str(e)[:100]}...")
            continue
        except Exception as e:
            print(f"✗ Error with {encoding}: {e}")
            continue
    
    if content is None:
        print("ERROR: Could not read file with any encoding!")
        return
    
    print(f"File size: {len(content)} characters")
    print()
    
    # Parse with BeautifulSoup
    try:
        soup = BeautifulSoup(content, "html.parser")
        print("✓ Successfully parsed HTML")
    except Exception as e:
        print(f"✗ Error parsing HTML: {e}")
        return
    
    # Check title
    title = soup.title.string if soup.title else "No title"
    print(f"Title: {title}")
    print()
    
    # Look for tables
    tables = soup.find_all("table")
    print(f"Found {len(tables)} table(s)")
    
    if tables:
        for i, table in enumerate(tables):
            print(f"\nTable {i+1}:")
            rows = table.find_all("tr")
            print(f"  - {len(rows)} rows")
            
            # Show first few rows
            for j, row in enumerate(rows[:3]):
                cols = row.find_all(["td", "th"])
                col_texts = [col.get_text(strip=True) for col in cols]
                print(f"    Row {j+1}: {col_texts}")
            
            if len(rows) > 3:
                print(f"    ... and {len(rows) - 3} more rows")
    
    # Look for order-related text patterns
    print("\nSearching for order patterns:")
    text = soup.get_text()
    
    # Order number patterns
    order_patterns = [
        r'Order.*?(\d+)',
        r'PO.*?(\d+)',
        r'Purchase.*?Order.*?(\d+)',
        r'#\s*(\d+)',
    ]
    
    for pattern in order_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            print(f"  Order numbers found with '{pattern}': {matches}")
    
    # Date patterns
    date_patterns = [
        r'\d{2}/\d{2}/\d{4}',
        r'\d{4}-\d{2}-\d{2}',
        r'\d{2}/\d{2}/\d{2}',
    ]
    
    for pattern in date_patterns:
        matches = re.findall(pattern, text)
        if matches:
            print(f"  Dates found with '{pattern}': {matches}")
    
    # UNFI patterns
    unfi_matches = re.findall(r'UNFI[^\\n]{0,50}', text, re.IGNORECASE)
    if unfi_matches:
        print(f"  UNFI references: {unfi_matches[:3]}")
    
    # Show sample text
    print(f"\nFirst 500 characters of text content:")
    print("-" * 30)
    print(text[:500])
    print("-" * 30)
    
    return content, soup

if __name__ == "__main__":
    file_path = r"c:\Users\risha\Downloads\UNFI WEST Purchase Order 446758464 08_30_24.html"
    debug_unfi_west_file(file_path)
