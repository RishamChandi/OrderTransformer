#!/usr/bin/env python3
"""
Launch the UNFI Order Processor Streamlit App
"""

import subprocess
import sys
import os
import webbrowser
import time

def launch_app():
    """Launch the Streamlit app"""
    print("🚀 LAUNCHING UNFI ORDER PROCESSOR")
    print("=" * 40)
    
    # Check if we're in the right directory
    if not os.path.exists("streamlit_app.py"):
        print("❌ Error: streamlit_app.py not found")
        print("Please run this script from the project root directory")
        return False
    
    print("✅ Found streamlit_app.py")
    print("✅ Starting Streamlit server...")
    print()
    print("📖 INSTRUCTIONS:")
    print("1. The app will open in your browser automatically")
    print("2. If it doesn't open, go to: http://localhost:8501")
    print("3. Upload test files from the 'test_files' folder")
    print("4. Press Ctrl+C in this terminal to stop the server")
    print()
    print("🧪 Test files available:")
    if os.path.exists("test_files"):
        for file in os.listdir("test_files"):
            print(f"   - test_files/{file}")
    print()
    
    # Give user a moment to read
    time.sleep(2)
    
    try:
        # Launch Streamlit
        result = subprocess.run([
            sys.executable, "-m", "streamlit", "run", "streamlit_app.py",
            "--server.port", "8501",
            "--server.headless", "false",
            "--browser.gatherUsageStats", "false"
        ], check=True)
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Error launching app: {e}")
        return False
    except KeyboardInterrupt:
        print("\n🛑 App stopped by user")
        return True
    
    return True

if __name__ == "__main__":
    print("UNFI Order Processor - Local App Launcher")
    print("=" * 50)
    
    # Check Python and Streamlit
    try:
        import streamlit
        print(f"✅ Python {sys.version}")
        print(f"✅ Streamlit {streamlit.__version__}")
    except ImportError:
        print("❌ Streamlit not installed. Install with: pip install streamlit")
        sys.exit(1)
    
    print()
    success = launch_app()
    
    if success:
        print("✅ App launch completed successfully!")
    else:
        print("❌ App launch failed!")
        
    print("\nThank you for using the UNFI Order Processor! 🎉")
