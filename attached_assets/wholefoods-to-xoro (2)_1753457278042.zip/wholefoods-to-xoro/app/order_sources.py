from main import extract_order_data as extract_order_data_wholefoods
from unfi_west_transformer import extract_order_data_unfi_west
from unfi_east_transformer import extract_order_data_unfi_east
import os
import re

def extract_order_data_unfi(path):
    """
    Extract order data from UNFI CSV or Excel files.
    Handles both CSV and Excel formats with flexible column mapping.
    """
    import pandas as pd
    import os
    
    # Determine file type and read accordingly
    file_ext = os.path.splitext(path)[1].lower()
    
    try:
        if file_ext == '.csv':
            # Fallback: read as lines and process manually for malformed CSVs
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Parse manually into list of lists
            rows = []
            for line in lines:
                line = line.strip()
                if line:
                    # Split by comma but handle potential quotes
                    parts = [part.strip() for part in line.split(',')]
                    rows.append(parts)
            
            # Find max columns
            max_cols = max(len(row) for row in rows) if rows else 0
            
            # Pad all rows to same length
            for row in rows:
                while len(row) < max_cols:
                    row.append('')
            
            # Create DataFrame
            df = pd.DataFrame(rows)
                    
        elif file_ext in ['.xlsx', '.xls']:
            df = pd.read_excel(path, header=None)
        else:
            raise ValueError(f"Unsupported file format: {file_ext}")
    except Exception as e:
        print(f"Error reading file {path}: {e}")
        return {"metadata": {}, "line_items": []}
    
    if df.empty:
        return {"metadata": {}, "line_items": []}
    
    # Extract metadata from first few rows or specific patterns
    metadata = {}
    
    # Look for order information in the first few rows
    for i in range(min(5, len(df))):
        row = df.iloc[i]
        for col_idx in range(len(row)):
            if col_idx < len(row) and pd.notna(row.iloc[col_idx]):
                cell_value = str(row.iloc[col_idx]).strip()
                
                # Look for order number patterns
                if any(keyword in cell_value.lower() for keyword in ['order', 'po', 'purchase']):
                    order_match = re.search(r'(\w+\d+|\d+)', cell_value)
                    if order_match and 'order_number' not in metadata:
                        metadata['order_number'] = order_match.group(1)
                
                # Look for date patterns
                date_match = re.search(r'(\d{1,2}/\d{1,2}/\d{4}|\d{4}-\d{2}-\d{2})', cell_value)
                if date_match and 'order_date' not in metadata:
                    metadata['order_date'] = date_match.group(1)
                
                # Look for customer/store information
                if any(keyword in cell_value.lower() for keyword in ['customer', 'store', 'unfi']):
                    if 'customer_name' not in metadata and len(cell_value) > 3:
                        metadata['customer_name'] = cell_value
    
    # Find the start of line items data
    # Look for headers that indicate line items
    line_item_headers = ['item', 'product', 'sku', 'quantity', 'qty', 'description', 'cost', 'price', 'upc']
    data_start_row = 0
    headers_found = False
    
    for i in range(min(10, len(df))):
        row_text = ' '.join(str(df.iloc[i][col_idx]).lower() for col_idx in range(len(df.columns)) if col_idx < len(df.iloc[i]) and pd.notna(df.iloc[i].iloc[col_idx]))
        header_matches = sum(1 for header in line_item_headers if header in row_text)
        if header_matches >= 2:  # At least 2 headers match
            data_start_row = i + 1
            headers_found = True
            break
    
    # If no clear headers found, assume data starts from a reasonable row
    if not headers_found:
        # Look for rows with numeric data (likely line items)
        for i in range(min(5, len(df))):
            row = df.iloc[i]
            numeric_count = sum(1 for val in row if pd.notna(val) and str(val).replace('.', '').replace(',', '').isdigit())
            if numeric_count >= 2:  # At least 2 numeric values
                data_start_row = i
                break
    
    # Extract line items
    line_items = []
    
    if data_start_row < len(df):
        # Get column mappings based on header names
        col_mapping = {}
        if data_start_row > 0:
            header_row = df.iloc[data_start_row - 1]
        else:
            header_row = df.iloc[0] if len(df) > 0 else pd.Series()
        
        for i, header in enumerate(header_row):
            if pd.notna(header):
                header_lower = str(header).lower().strip()
                
                if any(keyword in header_lower for keyword in ['item', 'product', 'sku']):
                    col_mapping['item_no'] = i
                elif any(keyword in header_lower for keyword in ['qty', 'quantity']):
                    col_mapping['qty'] = i
                elif any(keyword in header_lower for keyword in ['description', 'desc']):
                    col_mapping['description'] = i
                elif any(keyword in header_lower for keyword in ['cost', 'price']):
                    col_mapping['cost'] = i
                elif 'upc' in header_lower:
                    col_mapping['upc'] = i
                elif any(keyword in header_lower for keyword in ['size', 'pack']):
                    col_mapping['size'] = i
        
        # Extract data rows
        for i in range(data_start_row, len(df)):
            row = df.iloc[i]
            
            # Skip empty rows
            if row.isna().all() or all(str(val).strip() == '' for val in row):
                continue
            
            line_item = {}
            
            # Map columns to line item fields
            for field, col_idx in col_mapping.items():
                if col_idx < len(row):
                    value = str(row.iloc[col_idx]).strip() if col_idx < len(row) else ""
                    line_item[field] = value if value != 'nan' else ""
            
            # Fill in missing fields with empty strings
            for field in ['line', 'item_no', 'qty', 'description', 'size', 'cost', 'upc']:
                if field not in line_item:
                    line_item[field] = ""
            
            # Add line number
            line_item['line'] = str(len(line_items) + 1)
            
            # Only add if we have essential data
            if line_item.get('item_no') and line_item.get('qty'):
                line_items.append(line_item)
    
    return {"metadata": metadata, "line_items": line_items}

def extract_order_data_tkmaxx(path):
    # TODO: Implement TK Maxx parser
    return {"metadata": {}, "line_items": []}

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

ORDER_SOURCES = {
    "Whole Foods": {
        "parser": extract_order_data_wholefoods,
        "item_mapping": os.path.join(BASE_DIR, "mappings/wholefoods/item_mapping.xlsx"),
        "store_mapping": os.path.join(BASE_DIR, "mappings/wholefoods/store_mapping.xlsx"),
        "file_types": ["html"]
    },
    "UNFI West": {
        "parser": extract_order_data_unfi_west,
        "item_mapping": os.path.join(BASE_DIR, "mappings/unfi_west/item_mapping.xlsx"),
        "store_mapping": os.path.join(BASE_DIR, "mappings/unfi_west/store_mapping.xlsx"),
        "file_types": ["html"]
    },
    "UNFI East": {
        "parser": extract_order_data_unfi_east,
        "item_mapping": os.path.join(BASE_DIR, "mappings/unfi_east/item_mapping.xlsx"),
        "store_mapping": os.path.join(BASE_DIR, "mappings/unfi_east/store_mapping.xlsx"),
        "file_types": ["html"]
    },
    "UNFI": {
        "parser": extract_order_data_unfi,
        "item_mapping": os.path.join(BASE_DIR, "mappings/unfi/item_mapping.xlsx"),
        "store_mapping": os.path.join(BASE_DIR, "mappings/unfi/store_mapping.xlsx"),
        "file_types": ["csv", "xlsx"]
    },
    "TK Maxx": {
        "parser": extract_order_data_tkmaxx,
        "item_mapping": os.path.join(BASE_DIR, "mappings/tkmaxx/item_mapping.xlsx"),
        "store_mapping": os.path.join(BASE_DIR, "mappings/tkmaxx/store_mapping.xlsx"),
        "file_types": ["csv", "xlsx"]
    },
}