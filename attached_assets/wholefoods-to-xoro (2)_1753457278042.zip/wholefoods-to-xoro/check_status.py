#!/usr/bin/env python3
"""
UNFI Order Processor Implementation Status Check
Comprehensive verification of all components
"""

import os
import sys
import pandas as pd
from pathlib import Path

def check_file_exists(file_path, description):
    """Check if a file exists and return status"""
    if os.path.exists(file_path):
        size = os.path.getsize(file_path)
        return f"✅ {description} ({size} bytes)"
    else:
        return f"❌ {description} - MISSING"

def check_function_in_file(file_path, function_name):
    """Check if a function exists in a Python file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            if f"def {function_name}" in content:
                return f"✅ Function '{function_name}' implemented"
            else:
                return f"❌ Function '{function_name}' - NOT FOUND"
    except Exception as e:
        return f"❌ Error checking {file_path}: {e}"

def check_mapping_files():
    """Check all mapping files"""
    print("\n📁 MAPPING FILES")
    print("="*50)
    
    base_dir = os.path.dirname(__file__)
    mapping_files = [
        ("mappings/wholefoods/item_mapping.xlsx", "Whole Foods Item Mapping"),
        ("mappings/wholefoods/store_mapping.xlsx", "Whole Foods Store Mapping"),
        ("mappings/unfi_west/item_mapping.xlsx", "UNFI West Item Mapping"),
        ("mappings/unfi_west/store_mapping.xlsx", "UNFI West Store Mapping"),
        ("mappings/unfi_east/item_mapping.xlsx", "UNFI East Item Mapping"),
        ("mappings/unfi_east/store_mapping.xlsx", "UNFI East Store Mapping"),
        ("mappings/unfi/item_mapping.xlsx", "UNFI General Item Mapping"),
        ("mappings/unfi/store_mapping.xlsx", "UNFI General Store Mapping"),
    ]
    
    for file_path, description in mapping_files:
        full_path = os.path.join(base_dir, file_path)
        print(check_file_exists(full_path, description))

def check_transformer_files():
    """Check transformer implementation files"""
    print("\n🔧 TRANSFORMER FILES")
    print("="*50)
    
    base_dir = os.path.dirname(__file__)
    
    # Check main transformer files
    transformers = [
        ("unfi_west_transformer.py", "UNFI West Transformer"),
        ("unfi_east_transformer.py", "UNFI East Transformer"),
        ("main.py", "Whole Foods Parser"),
        ("mapper.py", "Item/Store Mapper"),
        ("generator.py", "Xoro Row Generator"),
    ]
    
    for file_path, description in transformers:
        full_path = os.path.join(base_dir, file_path)
        print(check_file_exists(full_path, description))
    
    # Check specific functions
    print("\n🔍 FUNCTION IMPLEMENTATIONS")
    print("-" * 30)
    
    functions_to_check = [
        ("unfi_west_transformer.py", "transform_unfi_west_order"),
        ("unfi_east_transformer.py", "extract_order_data_unfi_east"),
        ("unfi_east_transformer.py", "transform_unfi_east_order"),
        ("app/order_sources.py", "extract_order_data_unfi"),
        ("main.py", "extract_order_data"),
        ("mapper.py", "map_item_number"),
        ("mapper.py", "map_store_info"),
        ("generator.py", "build_xoro_row"),
    ]
    
    for file_path, function_name in functions_to_check:
        full_path = os.path.join(base_dir, file_path)
        print(check_function_in_file(full_path, function_name))

def check_test_files():
    """Check test implementation"""
    print("\n🧪 TEST FILES")
    print("="*50)
    
    base_dir = os.path.dirname(__file__)
    test_files = [
        ("tests/test_unfi_processors.py", "UNFI Processors Tests"),
        ("tests/test_unfi_integration.py", "UNFI Integration Tests"),
        ("tests/run_tests.py", "Test Runner"),
        ("tests/test_config.ini", "Test Configuration"),
    ]
    
    for file_path, description in test_files:
        full_path = os.path.join(base_dir, file_path)
        print(check_file_exists(full_path, description))

def check_integration():
    """Check integration with main application"""
    print("\n🔗 INTEGRATION CHECK")
    print("="*50)
    
    try:
        # Import order sources to check integration
        sys.path.append(os.path.dirname(__file__))
        from app.order_sources import ORDER_SOURCES
        
        unfi_sources = ["UNFI West", "UNFI East", "UNFI"]
        
        for source in unfi_sources:
            if source in ORDER_SOURCES:
                config = ORDER_SOURCES[source]
                
                # Check parser is callable
                if callable(config.get("parser")):
                    parser_status = "✅ Parser function available"
                else:
                    parser_status = "❌ Parser function missing"
                
                # Check file types
                file_types = config.get("file_types", [])
                if file_types:
                    types_status = f"✅ File types: {', '.join(file_types)}"
                else:
                    types_status = "❌ No file types specified"
                
                print(f"📋 {source}:")
                print(f"   {parser_status}")
                print(f"   {types_status}")
                print(f"   Item mapping: {config.get('item_mapping', 'Not specified')}")
                print(f"   Store mapping: {config.get('store_mapping', 'Not specified')}")
            else:
                print(f"❌ {source} - NOT CONFIGURED")
        
    except Exception as e:
        print(f"❌ Error checking integration: {e}")

def check_dependencies():
    """Check required dependencies"""
    print("\n📦 DEPENDENCIES")
    print("="*50)
    
    required_modules = [
        ('pandas', 'Data processing'),
        ('bs4', 'HTML parsing'),
        ('openpyxl', 'Excel file handling'),
        ('streamlit', 'Web interface'),
    ]
    
    for module, description in required_modules:
        try:
            __import__(module)
            print(f"✅ {module} - {description}")
        except ImportError:
            print(f"❌ {module} - MISSING - {description}")

def run_quick_functionality_test():
    """Run a quick test of core functionality"""
    print("\n⚡ QUICK FUNCTIONALITY TEST")
    print("="*50)
    
    try:
        # Test HTML parsing
        from bs4 import BeautifulSoup
        test_html = "<html><body><div>Test</div></body></html>"
        soup = BeautifulSoup(test_html, 'html.parser')
        print("✅ HTML parsing works")
        
        # Test pandas operations
        import pandas as pd
        test_df = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
        print("✅ Pandas operations work")
        
        # Test mapper function
        sys.path.append(os.path.dirname(__file__))
        from mapper import map_item_number
        
        # Create test mapping
        test_mapping = pd.DataFrame({
            'UNFI_ItemNo': ['12345'],
            'Xoro_ItemNo': ['XORO-12345']
        })
        result = map_item_number('12345', test_mapping)
        if result == 'XORO-12345':
            print("✅ Item mapping function works")
        else:
            print(f"⚠️  Item mapping function returned: {result}")
            
    except Exception as e:
        print(f"❌ Functionality test failed: {e}")

def generate_summary():
    """Generate implementation summary"""
    print("\n📊 IMPLEMENTATION SUMMARY")
    print("="*70)
    
    # Count implemented vs missing components
    implemented = []
    missing = []
    
    # Check key files
    key_files = [
        "unfi_west_transformer.py",
        "unfi_east_transformer.py", 
        "app/order_sources.py",
        "tests/test_unfi_processors.py",
        "mappings/unfi_west/item_mapping.xlsx",
        "mappings/unfi_east/store_mapping.xlsx"
    ]
    
    base_dir = os.path.dirname(__file__)
    
    for file in key_files:
        if os.path.exists(os.path.join(base_dir, file)) and os.path.getsize(os.path.join(base_dir, file)) > 0:
            implemented.append(file)
        else:
            missing.append(file)
    
    print(f"✅ Implemented components: {len(implemented)}")
    print(f"❌ Missing components: {len(missing)}")
    
    completion_rate = (len(implemented) / len(key_files)) * 100
    print(f"📈 Implementation completion: {completion_rate:.1f}%")
    
    if completion_rate >= 90:
        status = "🎉 EXCELLENT - Production ready!"
    elif completion_rate >= 70:
        status = "👍 GOOD - Minor issues to resolve"
    elif completion_rate >= 50:
        status = "⚠️  FAIR - Significant work needed"
    else:
        status = "❌ POOR - Major implementation required"
    
    print(f"Overall Status: {status}")

def main():
    """Main status check function"""
    print("🔍 UNFI ORDER PROCESSOR - IMPLEMENTATION STATUS")
    print("="*70)
    print(f"Checking implementation in: {os.path.dirname(__file__)}")
    
    check_dependencies()
    check_transformer_files()
    check_mapping_files()
    check_test_files()
    check_integration()
    run_quick_functionality_test()
    generate_summary()
    
    print("\n" + "="*70)
    print("✅ Status check completed!")

if __name__ == "__main__":
    main()
