#!/usr/bin/env python3
"""
Debug version of UNFI West parser with detailed logging
"""

from bs4 import BeautifulSoup
import re
import os

def debug_extract_order_data_unfi_west(html_path):
    """
    Debug version of UNFI West extractor with detailed logging
    """
    print(f"🔍 Starting debug analysis of: {html_path}")
    print("=" * 60)
    
    # Check file existence
    if not os.path.exists(html_path):
        print("❌ File does not exist!")
        return {"metadata": {}, "line_items": []}
    
    file_size = os.path.getsize(html_path)
    print(f"📁 File size: {file_size:,} bytes")
    
    # Parse HTML file with encoding handling
    content = None
    encodings_to_try = ['cp1252', 'windows-1252', 'latin-1', 'utf-8', 'iso-8859-1', 'utf-16']
    
    for encoding in encodings_to_try:
        try:
            with open(html_path, encoding=encoding) as f:
                content = f.read()
            print(f"✅ Successfully read with encoding: {encoding}")
            break
        except UnicodeDecodeError as e:
            print(f"❌ Failed with {encoding}: {str(e)[:100]}...")
            continue
        except Exception as e:
            print(f"❌ Error with {encoding}: {e}")
            continue
    
    if content is None:
        print("❌ Could not decode file with any supported encoding")
        return {"metadata": {}, "line_items": []}
    
    print(f"📄 Content length: {len(content):,} characters")
    
    # Parse with BeautifulSoup
    soup = BeautifulSoup(content, "html.parser")
    print("✅ HTML parsed successfully")

    # Extract metadata
    metadata = {}
    print("\n🔍 EXTRACTING METADATA...")
    
    # Extract from title
    if soup.title and soup.title.string:
        title_text = soup.title.string.strip()
        print(f"📋 Title found: '{title_text}'")
        
        # Look for "Purchase Order XXXXXXX" pattern
        order_match = re.search(r'Purchase\s+Order\s+(\d+)', title_text, re.IGNORECASE)
        if order_match:
            metadata["order_number"] = order_match.group(1)
            print(f"✅ Order number from title: {metadata['order_number']}")
        else:
            # Fallback to any number in title
            order_match = re.search(r'(\d{6,})', title_text)
            if order_match:
                metadata["order_number"] = order_match.group(1)
                print(f"✅ Order number (fallback): {metadata['order_number']}")
        
        # Extract date from title
        date_match = re.search(r'(\d{2}/\d{2}/\d{2,4})', title_text)
        if date_match:
            metadata["order_date"] = date_match.group(1)
            print(f"✅ Order date from title: {metadata['order_date']}")
    else:
        print("❌ No title found")
    
    # Extract customer name
    full_text = soup.get_text()
    customer_name_tag = soup.find(string=re.compile(r"UNFI", re.IGNORECASE))
    if customer_name_tag:
        metadata["customer_name"] = customer_name_tag.strip()
        print(f"✅ Customer name: {metadata['customer_name']}")
    else:
        print("❌ No UNFI customer name found")
    
    print(f"\n📊 Final metadata: {metadata}")

    # Extract line items
    print("\n🔍 EXTRACTING LINE ITEMS...")
    line_items = []
    
    # Look for all tables
    tables = soup.find_all("table")
    print(f"📋 Found {len(tables)} table(s)")
    
    if not tables:
        print("❌ No tables found in HTML")
        return {"metadata": metadata, "line_items": line_items}
    
    for table_idx, table in enumerate(tables):
        print(f"\n📋 Analyzing Table {table_idx + 1}:")
        rows = table.find_all("tr")
        print(f"   Rows: {len(rows)}")
        
        if len(rows) < 2:
            print("   ❌ Insufficient rows (need header + data)")
            continue
        
        # Analyze header row
        header_row = rows[0]
        header_cells = header_row.find_all(["th", "td"])
        header_texts = [cell.get_text(strip=True).lower() for cell in header_cells]
        print(f"   📋 Headers: {header_texts}")
        
        # Look for typical order line headers
        expected_headers = ['item', 'qty', 'quantity', 'description', 'cost', 'price', 'upc', 'line', 'product']
        header_matches = sum(1 for header in header_texts if any(exp in header for exp in expected_headers))
        print(f"   🎯 Header matches: {header_matches}")
        
        if header_matches >= 2:
            print("   ✅ This looks like a data table!")
            
            # Process data rows
            data_rows = rows[1:]
            table_items = []
            
            for row_idx, row in enumerate(data_rows):
                cols = row.find_all(["td", "th"])
                if len(cols) >= 3:
                    col_texts = [col.get_text(strip=True) for col in cols]
                    
                    # Skip empty rows
                    if not any(col_texts):
                        continue
                    
                    print(f"   📝 Row {row_idx + 1}: {col_texts}")
                    
                    # Try to create line item
                    line_item = {}
                    
                    if len(col_texts) >= 7:
                        line_item = {
                            "line": col_texts[0] if col_texts[0] else str(len(table_items) + 1),
                            "item_no": col_texts[1],
                            "qty": col_texts[2],
                            "description": col_texts[3],
                            "size": col_texts[4],
                            "cost": col_texts[5],
                            "upc": col_texts[6],
                        }
                    elif len(col_texts) >= 4:
                        line_item = {
                            "line": str(len(table_items) + 1),
                            "item_no": col_texts[0],
                            "qty": col_texts[1],
                            "description": col_texts[2],
                            "size": col_texts[3] if len(col_texts) > 3 else "",
                            "cost": col_texts[4] if len(col_texts) > 4 else "",
                            "upc": col_texts[5] if len(col_texts) > 5 else "",
                        }
                    
                    # Validate essential data
                    if line_item and line_item.get("item_no") and line_item.get("qty"):
                        # Clean up the data
                        for key, value in line_item.items():
                            line_item[key] = str(value).strip() if value else ""
                        table_items.append(line_item)
                        print(f"   ✅ Added item: {line_item}")
                    else:
                        print(f"   ❌ Skipped row (missing essential data)")
            
            if table_items:
                line_items.extend(table_items)
                print(f"   ✅ Found {len(table_items)} items in this table")
                break  # Found data, stop looking
            else:
                print("   ❌ No valid items found in this table")
        else:
            print("   ❌ Not a data table (insufficient header matches)")
            
            # Show sample rows anyway
            for row_idx, row in enumerate(rows[:3]):
                cols = row.find_all(["td", "th"])
                col_texts = [col.get_text(strip=True) for col in cols]
                print(f"   📝 Sample Row {row_idx + 1}: {col_texts}")
    
    print(f"\n🎯 FINAL RESULTS:")
    print(f"   Metadata: {metadata}")
    print(f"   Line items: {len(line_items)}")
    
    if line_items:
        print("\n✅ Sample line items:")
        for i, item in enumerate(line_items[:3]):
            print(f"   {i+1}: {item}")
    else:
        print("\n❌ No line items extracted!")
        
        # Show some raw text for manual inspection
        print(f"\n📄 First 1000 characters of text content:")
        print("-" * 50)
        print(full_text[:1000])
        print("-" * 50)

    return {"metadata": metadata, "line_items": line_items}

if __name__ == "__main__":
    file_path = r"c:\Users\risha\Downloads\UNFI WEST Purchase Order 446758464 08_30_24.html"
    result = debug_extract_order_data_unfi_west(file_path)
