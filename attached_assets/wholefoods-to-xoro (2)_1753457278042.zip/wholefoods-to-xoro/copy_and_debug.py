#!/usr/bin/env python3
"""
Copy and analyze UNFI West file content
"""

import os
import shutil

def copy_and_analyze():
    source = r"c:\Users\risha\Downloads\UNFI WEST Purchase Order 446758464 08_30_24.html"
    dest = r"c:\Users\risha\VS CODE PROJECTS\wholefoods-to-xoro\copied_unfi_west.html"
    
    print(f"Copying {source} to {dest}")
    
    try:
        # Copy file
        shutil.copy2(source, dest)
        print("✅ File copied successfully")
        
        # Read and show basic info
        with open(dest, 'r', encoding='cp1252') as f:
            content = f.read()
        
        print(f"📄 File size: {len(content):,} characters")
        print(f"📄 First 500 characters:")
        print("-" * 50)
        print(content[:500])
        print("-" * 50)
        
        return dest
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return None

if __name__ == "__main__":
    copied_file = copy_and_analyze()
    
    if copied_file:
        print(f"\n🔍 Now running debug parser on copied file...")
        from debug_verbose_unfi import debug_extract_order_data_unfi_west
        result = debug_extract_order_data_unfi_west(copied_file)
