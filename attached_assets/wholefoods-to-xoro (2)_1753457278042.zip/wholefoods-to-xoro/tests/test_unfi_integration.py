import unittest
import tempfile
import os
import sys
import pandas as pd

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.order_sources import ORDER_SOURCES
from generator import build_xoro_row
from mapper import load_mappings


class TestUNFIIntegrationWithXoro(unittest.TestCase):
    """Test UNFI processors integration with Xoro transformation"""
    
    def setUp(self):
        """Set up test fixtures"""
        # Create sample UNFI HTML order
        self.unfi_html = """
        <html>
            <body>
                <div>UNFI East - Store #10001</div>
                <div>Order Date: 03/15/2024</div>
                <div>Order #EAST123</div>
                <table>
                    <tr>
                        <th>Line</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Description</th>
                        <th>Size</th>
                        <th>Cost</th>
                        <th>UPC</th>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>54321</td>
                        <td>15</td>
                        <td>Integration Test Product</td>
                        <td>12/16oz</td>
                        <td>$24.99</td>
                        <td>123123123123</td>
                    </tr>
                </table>
            </body>
        </html>
        """
        
        self.temp_html = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
        self.temp_html.write(self.unfi_html)
        self.temp_html.close()
        
        # Create sample item mapping
        self.item_mapping = pd.DataFrame({
            'UNFI_ItemNo': ['54321'],
            'Xoro_ItemNo': ['XORO-54321'],
            'Description': ['Integration Test Product']
        })
        
        self.temp_item_mapping = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
        self.item_mapping.to_excel(self.temp_item_mapping.name, index=False)
        self.temp_item_mapping.close()
        
        # Create sample store mapping
        self.store_mapping = pd.DataFrame({
            'StoreNo': ['10001'],
            'UNFI Customer Name': ['UNFI East - Store #10001'],
            'Xoro Customer Name': ['Test Customer East'],
            'CustomerId': ['CUST001'],
            'AccountNumber': ['ACC001'],
            'CompanyName': ['Test Company East'],
            'ShipToCompanyName': ['Ship To Test East']
        })
        
        self.temp_store_mapping = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
        self.store_mapping.to_excel(self.temp_store_mapping.name, index=False)
        self.temp_store_mapping.close()
        
        # Create Xoro template
        self.template_columns = [
            '**DateToBeShipped', '**OrderDate', '**ItemNumber', 'ItemNotes',
            '**UnitPrice', '**Qty', '**CurrencyCode', '**ExchangeRate',
            '**CustomerName', '**SaleStoreName', 'StoreName', 'ThirdPartyRefNo',
            'RefNo', 'CustomerPO', 'SalesRepId', 'CustomFieldD1'
        ]
    
    def tearDown(self):
        """Clean up test fixtures"""
        os.unlink(self.temp_html.name)
        os.unlink(self.temp_item_mapping.name)
        os.unlink(self.temp_store_mapping.name)
    
    def test_unfi_east_end_to_end_processing(self):
        """Test complete UNFI East processing pipeline"""
        # Parse order data
        parser = ORDER_SOURCES["UNFI East"]["parser"]
        order_data = parser(self.temp_html.name)
        
        # Load mappings
        item_mapping_df, store_mapping_df = load_mappings(
            self.temp_item_mapping.name,
            self.temp_store_mapping.name
        )
        
        # Process line items
        xoro_rows = []
        for line_item in order_data['line_items']:
            row = build_xoro_row(
                order_data,
                line_item,
                item_mapping_df,
                store_mapping_df,
                self.template_columns
            )
            xoro_rows.append(row)
        
        # Verify results
        self.assertGreater(len(xoro_rows), 0)
        
        first_row = xoro_rows[0]
        
        # Check that essential fields are populated
        self.assertIn('**ItemNumber', first_row)
        self.assertIn('**Qty', first_row)
        self.assertIn('**CustomerName', first_row)
        self.assertIn('**OrderDate', first_row)
        
        # Verify data transformation
        self.assertEqual(first_row['**Qty'], '15')
        self.assertEqual(first_row['**CustomerName'], 'Test Company East')
    
    def test_unfi_csv_end_to_end_processing(self):
        """Test complete UNFI CSV processing pipeline"""
        # Create sample CSV
        csv_data = """Order,UNFI789,Date,04/01/2024
Store,10001,Customer,UNFI CSV Customer

Item,Quantity,Description,Cost
54321,20,CSV Test Product,$15.50
"""
        
        temp_csv = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False)
        temp_csv.write(csv_data)
        temp_csv.close()
        
        try:
            # Parse order data
            parser = ORDER_SOURCES["UNFI"]["parser"]
            order_data = parser(temp_csv.name)
            
            # Load mappings
            item_mapping_df, store_mapping_df = load_mappings(
                self.temp_item_mapping.name,
                self.temp_store_mapping.name
            )
            
            # Process line items
            xoro_rows = []
            for line_item in order_data['line_items']:
                row = build_xoro_row(
                    order_data,
                    line_item,
                    item_mapping_df,
                    store_mapping_df,
                    self.template_columns
                )
                xoro_rows.append(row)
            
            # Verify we got some results
            self.assertGreaterEqual(len(xoro_rows), 0)
            
        finally:
            os.unlink(temp_csv.name)
    
    def test_all_unfi_sources_available(self):
        """Test that all UNFI sources are properly configured"""
        unfi_sources = ["UNFI West", "UNFI East", "UNFI"]
        
        for source in unfi_sources:
            self.assertIn(source, ORDER_SOURCES)
            
            config = ORDER_SOURCES[source]
            
            # Check required keys
            required_keys = ["parser", "item_mapping", "store_mapping", "file_types"]
            for key in required_keys:
                self.assertIn(key, config)
            
            # Check that parser is callable
            self.assertTrue(callable(config["parser"]))
            
            # Check file types
            self.assertIsInstance(config["file_types"], list)
            self.assertGreater(len(config["file_types"]), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
