import unittest
import tempfile
import os
import sys
import pandas as pd
from unittest.mock import patch, mock_open

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from unfi_west_transformer import transform_unfi_west_order
from unfi_east_transformer import extract_order_data_unfi_east, transform_unfi_east_order
from app.order_sources import extract_order_data_unfi


class TestUNFIWestTransformer(unittest.TestCase):
    """Test UNFI West order transformer"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.sample_html = """
        <html>
            <body>
                <div>UNFI - West Coast Distribution</div>
                <div>Order Date: 12/15/2023</div>
                <div>Order #12345</div>
                <table>
                    <tr>
                        <th>Line</th>
                        <th>Item No.</th>
                        <th>Qty</th>
                        <th>Description</th>
                        <th>Size</th>
                        <th>Cost</th>
                        <th>UPC</th>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>12345</td>
                        <td>10</td>
                        <td>Test Product 1</td>
                        <td>24/12oz</td>
                        <td>$15.99</td>
                        <td>123456789012</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>67890</td>
                        <td>5</td>
                        <td>Test Product 2</td>
                        <td>12/16oz</td>
                        <td>$22.50</td>
                        <td>987654321098</td>
                    </tr>
                </table>
            </body>
        </html>
        """
        
        # Create temporary files
        self.temp_html = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
        self.temp_html.write(self.sample_html)
        self.temp_html.close()
        
        # Create sample store mapping
        self.store_mapping_data = {
            'UNFI Customer Name': ['UNFI - West Coast Distribution'],
            'Xoro Customer Name': ['West Coast Customer']
        }
        self.temp_store_mapping = tempfile.NamedTemporaryFile(mode='w', suffix='.xlsx', delete=False)
        pd.DataFrame(self.store_mapping_data).to_excel(self.temp_store_mapping.name, index=False)
        self.temp_store_mapping.close()
        
        # Create sample template
        self.template_data = "CustomerName,OrderDate,ItemCode,Quantity,Description\n"
        self.temp_template = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False)
        self.temp_template.write(self.template_data)
        self.temp_template.close()
    
    def tearDown(self):
        """Clean up test fixtures"""
        os.unlink(self.temp_html.name)
        os.unlink(self.temp_store_mapping.name)
        os.unlink(self.temp_template.name)
    
    def test_transform_unfi_west_order(self):
        """Test UNFI West order transformation"""
        result = transform_unfi_west_order(
            self.temp_html.name,
            self.temp_store_mapping.name,
            self.temp_template.name
        )
        
        # Check that result is a DataFrame
        self.assertIsInstance(result, pd.DataFrame)
        
        # Check that we have the expected columns
        expected_columns = ['CustomerName', 'OrderDate', 'ItemCode', 'Quantity', 'Description']
        for col in expected_columns:
            self.assertIn(col, result.columns)


class TestUNFIEastTransformer(unittest.TestCase):
    """Test UNFI East order transformer"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.sample_html = """
        <html>
            <body>
                <div>UNFI East Distribution Center</div>
                <div>Order Date: 01/15/2024</div>
                <div>PO #54321</div>
                <table>
                    <tr>
                        <th>Line</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Description</th>
                        <th>Size</th>
                        <th>Cost</th>
                        <th>UPC</th>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>54321</td>
                        <td>8</td>
                        <td>East Product 1</td>
                        <td>6/32oz</td>
                        <td>$18.75</td>
                        <td>111111111111</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>98765</td>
                        <td>12</td>
                        <td>East Product 2</td>
                        <td>24/8oz</td>
                        <td>$14.25</td>
                        <td>222222222222</td>
                    </tr>
                </table>
            </body>
        </html>
        """
        
        self.temp_html = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
        self.temp_html.write(self.sample_html)
        self.temp_html.close()
    
    def tearDown(self):
        """Clean up test fixtures"""
        os.unlink(self.temp_html.name)
    
    def test_extract_order_data_unfi_east(self):
        """Test UNFI East order data extraction"""
        result = extract_order_data_unfi_east(self.temp_html.name)
        
        # Check structure
        self.assertIn('metadata', result)
        self.assertIn('line_items', result)
        
        # Check metadata
        metadata = result['metadata']
        self.assertIn('order_date', metadata)
        self.assertIn('order_number', metadata)
        
        # Check line items
        line_items = result['line_items']
        self.assertGreater(len(line_items), 0)
        
        # Check first line item structure
        first_item = line_items[0]
        required_fields = ['item_no', 'qty', 'description']
        for field in required_fields:
            self.assertIn(field, first_item)
            self.assertTrue(first_item[field])  # Should not be empty


class TestUNFIGeneralParser(unittest.TestCase):
    """Test general UNFI CSV/Excel parser"""
    
    def setUp(self):
        """Set up test fixtures"""
        # Create sample CSV data
        self.csv_data = """Order Number,12345
Order Date,01/20/2024
Customer,UNFI General Customer

Line,Item,Quantity,Description,Cost,UPC
1,11111,15,General Product 1,$12.99,333333333333
2,22222,20,General Product 2,$8.75,444444444444
3,33333,10,General Product 3,$25.00,555555555555
"""
        
        self.temp_csv = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False)
        self.temp_csv.write(self.csv_data)
        self.temp_csv.close()
        
        # Create sample Excel data
        self.excel_data = {
            'Order Info': ['Order Number: 67890', 'Order Date: 02/01/2024', 'Customer: UNFI Excel Customer'],
            'Col1': ['', '', ''],
            'Col2': ['', '', ''],
            'Col3': ['', '', '']
        }
        
        # Add line items
        line_items_df = pd.DataFrame({
            'Line': [1, 2, 3],
            'Item': ['44444', '55555', '66666'],
            'Quantity': [25, 30, 5],
            'Description': ['Excel Product 1', 'Excel Product 2', 'Excel Product 3'],
            'Cost': ['$19.99', '$11.50', '$35.75'],
            'UPC': ['666666666666', '777777777777', '888888888888']
        })
        
        self.temp_excel = tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False)
        with pd.ExcelWriter(self.temp_excel.name) as writer:
            pd.DataFrame(self.excel_data).to_excel(writer, sheet_name='Sheet1', index=False)
            line_items_df.to_excel(writer, sheet_name='Sheet1', startrow=5, index=False)
        self.temp_excel.close()
    
    def tearDown(self):
        """Clean up test fixtures"""
        os.unlink(self.temp_csv.name)
        os.unlink(self.temp_excel.name)
    
    def test_extract_order_data_unfi_csv(self):
        """Test UNFI CSV file parsing"""
        result = extract_order_data_unfi(self.temp_csv.name)
        
        # Check structure
        self.assertIn('metadata', result)
        self.assertIn('line_items', result)
        
        # Check that we extracted some line items
        line_items = result['line_items']
        self.assertGreater(len(line_items), 0)
        
        # Check line item structure
        first_item = line_items[0]
        self.assertIn('item_no', first_item)
        self.assertIn('qty', first_item)
        self.assertIn('description', first_item)
    
    def test_extract_order_data_unfi_excel(self):
        """Test UNFI Excel file parsing"""
        result = extract_order_data_unfi(self.temp_excel.name)
        
        # Check structure
        self.assertIn('metadata', result)
        self.assertIn('line_items', result)
        
        # Should handle Excel files without errors
        line_items = result['line_items']
        self.assertIsInstance(line_items, list)
    
    def test_unsupported_file_format(self):
        """Test handling of unsupported file formats"""
        # Create a temporary file with unsupported extension
        temp_txt = tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False)
        temp_txt.write("Some text content")
        temp_txt.close()
        
        try:
            result = extract_order_data_unfi(temp_txt.name)
            
            # Should return empty result for unsupported format
            self.assertEqual(result['metadata'], {})
            self.assertEqual(result['line_items'], [])
        finally:
            os.unlink(temp_txt.name)


class TestUNFIIntegration(unittest.TestCase):
    """Integration tests for UNFI processors"""
    
    def test_all_unfi_parsers_return_consistent_format(self):
        """Test that all UNFI parsers return the same data structure"""
        # Create temporary HTML file for testing
        sample_html = """
        <html>
            <body>
                <div>UNFI Test</div>
                <table>
                    <tr><th>Item</th><th>Qty</th><th>Description</th></tr>
                    <tr><td>12345</td><td>10</td><td>Test Item</td></tr>
                </table>
            </body>
        </html>
        """
        
        temp_html = tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False)
        temp_html.write(sample_html)
        temp_html.close()
        
        # Create temporary CSV file for testing
        sample_csv = "Item,Quantity,Description\n12345,10,Test Item\n"
        temp_csv = tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False)
        temp_csv.write(sample_csv)
        temp_csv.close()
        
        try:
            # Test UNFI East
            result_east = extract_order_data_unfi_east(temp_html.name)
            
            # Test general UNFI
            result_general = extract_order_data_unfi(temp_csv.name)
            
            # Both should have the same structure
            for result in [result_east, result_general]:
                self.assertIn('metadata', result)
                self.assertIn('line_items', result)
                self.assertIsInstance(result['metadata'], dict)
                self.assertIsInstance(result['line_items'], list)
        
        finally:
            os.unlink(temp_html.name)
            os.unlink(temp_csv.name)


if __name__ == '__main__':
    # Create test suite
    unittest.main(verbosity=2)
