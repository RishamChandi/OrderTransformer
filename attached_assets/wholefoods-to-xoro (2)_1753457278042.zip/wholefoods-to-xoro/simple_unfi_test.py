import sys
import os
from unfi_west_transformer import extract_order_data_unfi_west

def test_unfi_west_file():
    file_path = r"c:\Users\risha\Downloads\UNFI WEST Purchase Order 446758464 08_30_24.html"
    
    print(f"Testing UNFI West parser with: {file_path}")
    print("=" * 50)
    
    # Check if file exists
    if not os.path.exists(file_path):
        print("ERROR: File does not exist!")
        return
    
    # Get file size
    file_size = os.path.getsize(file_path)
    print(f"File size: {file_size:,} bytes")
    
    # Test the parser
    try:
        result = extract_order_data_unfi_west(file_path)
        
        print("\n=== PARSER RESULTS ===")
        print(f"Metadata: {result['metadata']}")
        print(f"Number of line items: {len(result['line_items'])}")
        
        if result['line_items']:
            print("\nFirst few line items:")
            for i, item in enumerate(result['line_items'][:5]):
                print(f"  {i+1}: {item}")
        else:
            print("❌ No line items found!")
            
            # Let's manually check the file content
            print("\n=== MANUAL FILE ANALYSIS ===")
            try:
                from bs4 import BeautifulSoup
                
                # Try reading with cp1252 encoding
                with open(file_path, 'r', encoding='cp1252') as f:
                    content = f.read()
                
                soup = BeautifulSoup(content, 'html.parser')
                
                print(f"✓ File read successfully with cp1252 encoding")
                print(f"Content length: {len(content):,} characters")
                
                # Check title
                if soup.title:
                    print(f"Title: {soup.title.string}")
                
                # Check tables
                tables = soup.find_all('table')
                print(f"Tables found: {len(tables)}")
                
                if tables:
                    for i, table in enumerate(tables):
                        rows = table.find_all('tr')
                        print(f"  Table {i+1}: {len(rows)} rows")
                        
                        # Show first few rows
                        for j, row in enumerate(rows[:3]):
                            cells = row.find_all(['td', 'th'])
                            cell_texts = [cell.get_text(strip=True) for cell in cells]
                            print(f"    Row {j+1}: {cell_texts}")
                
                # Show sample content
                text_content = soup.get_text()
                print(f"\nFirst 500 characters of text:")
                print("-" * 30)
                print(text_content[:500])
                print("-" * 30)
                
                # Look for key patterns
                import re
                order_matches = re.findall(r'(\d{6,})', text_content)
                if order_matches:
                    print(f"\nPotential order numbers: {order_matches[:5]}")
                
                date_matches = re.findall(r'(\d{2}/\d{2}/\d{2,4})', text_content)
                if date_matches:
                    print(f"Dates found: {date_matches}")
                    
            except Exception as e:
                print(f"Error in manual analysis: {e}")
                import traceback
                traceback.print_exc()
        
    except Exception as e:
        print(f"❌ Parser error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_unfi_west_file()
