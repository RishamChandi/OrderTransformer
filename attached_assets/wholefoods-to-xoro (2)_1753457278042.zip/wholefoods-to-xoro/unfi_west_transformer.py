from bs4 import BeautifulSoup
import re
import pandas as pd

def map_unfi_customer_to_xoro(customer_name, store_mapping_df):
    """
    Map UNFI customer name to Xoro customer name using the store mapping.
    
    Args:
        customer_name: The UNFI customer name (e.g., "UNFI - ROCKLIN, CA")
        store_mapping_df: DataFrame with CustomerName and XoroCustomerName columns
    
    Returns:
        Mapped Xoro customer name or "Unknown Customer" if no match found
    """
    if not customer_name or store_mapping_df.empty:
        return "Unknown Customer"
    
    # Try exact match first (case-insensitive)
    exact_match = store_mapping_df.loc[
        store_mapping_df["CustomerName"].str.upper() == customer_name.upper(), 
        "XoroCustomerName"
    ]
    if not exact_match.empty:
        return exact_match.values[0]
    
    # Try partial matching (case-insensitive)
    for idx, row in store_mapping_df.iterrows():
        stored_name = str(row["CustomerName"]).upper()
        input_name = customer_name.upper()
        
        # Check if either name contains the other
        if stored_name in input_name or input_name in stored_name:
            return row["XoroCustomerName"]
        
        # Try matching without punctuation and extra spaces
        stored_clean = re.sub(r'[^\w\s]', '', stored_name).strip()
        input_clean = re.sub(r'[^\w\s]', '', input_name).strip()
        
        if stored_clean == input_clean:
            return row["XoroCustomerName"]
    
    return "Unknown Customer"

def transform_unfi_west_order(html_path, store_mapping_path, template_path):
    """
    Transforms UNFI West order HTML file into Xoro sales order template.
    Returns a DataFrame representing the transformed order.
    """
    # Load store mapping
    store_mapping = pd.read_excel(store_mapping_path)

    # Load Xoro template
    xoro_template = pd.read_csv(template_path)

    # Parse HTML file with better encoding handling - prioritize windows-1252
    content = None
    encodings_to_try = ['cp1252', 'windows-1252', 'latin-1', 'utf-8', 'iso-8859-1', 'utf-16']
    
    for encoding in encodings_to_try:
        try:
            with open(html_path, encoding=encoding) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Error reading file with {encoding}: {e}")
            continue
    
    if content is None:
        print("Could not decode file with any supported encoding")
        return xoro_template
    
    soup = BeautifulSoup(content, "html.parser")

    # Extract metadata
    metadata = {}
    
    # Extract order number from title first
    if soup.title:
        title_text = soup.title.string
        if title_text:
            order_match = re.search(r'Order\s+(\d+)|(\d+)', title_text)
            if order_match:
                metadata["order_number"] = order_match.group(1) or order_match.group(2)
    
    # Look for UNFI location information to determine customer name
    # Pattern: "UNFI - LOCATION, STATE" (e.g., "UNFI - ROCKLIN, CA")
    text_content = soup.get_text()
    lines = text_content.split('\n')
    
    customer_name = None
    for line in lines:
        line = line.strip()
        
        # Look for UNFI location pattern (more specific first)
        unfi_location_match = re.search(r'UNFI\s*-\s*([A-Z\s]+),\s*([A-Z]{2})', line, re.IGNORECASE)
        if unfi_location_match:
            location = unfi_location_match.group(1).strip().upper()
            state = unfi_location_match.group(2).strip().upper()
            customer_name = f"UNFI - {location}, {state}"
            metadata["customer_name"] = customer_name
            break
    
    # Fallback: look for any UNFI reference if specific pattern not found
    if not customer_name:
        customer_name_tag = soup.find(string=re.compile(r"UNFI -"))
        if customer_name_tag:
            metadata["customer_name"] = customer_name_tag.strip()

    order_date_tag = soup.find(string=re.compile(r"\d{2}/\d{2}/\d{2}"))
    if order_date_tag:
        metadata["order_date"] = order_date_tag.strip()
    
    # Also extract from title if present
    if soup.title and soup.title.string:
        title_text = soup.title.string
        date_match = re.search(r'(\d{2}/\d{2}/\d{2})', title_text)
        if date_match and 'order_date' not in metadata:
            metadata['order_date'] = date_match.group(1)

    # Map customer name using store_mapping with correct column names
    metadata["xoro_customer_name"] = map_unfi_customer_to_xoro(
        metadata.get("customer_name"), store_mapping
    )

    # Extract line items
    line_items = []
    tables = soup.find_all("table")
    
    # Try each table to find the one with order data
    for table in tables:
        rows = table.find_all("tr")
        if len(rows) < 2:
            continue
            
        # Skip header row and process data rows
        data_rows = rows[1:]
        temp_items = []
        
        for row in data_rows:
            cols = row.find_all(["td", "th"])
            if len(cols) >= 3:  # Minimum columns needed
                col_texts = [col.get_text(strip=True) for col in cols]
                
                # Map based on available columns
                if len(col_texts) >= 7:
                    line_item = {
                        "line": col_texts[0] if col_texts[0] else str(len(temp_items) + 1),
                        "item_no": col_texts[1],
                        "qty": col_texts[2],
                        "description": col_texts[3],
                        "size": col_texts[4],
                        "cost": col_texts[5],
                        "upc": col_texts[6],
                    }
                elif len(col_texts) >= 4:
                    line_item = {
                        "line": str(len(temp_items) + 1),
                        "item_no": col_texts[0],
                        "qty": col_texts[1],
                        "description": col_texts[2],
                        "size": col_texts[3] if len(col_texts) > 3 else "",
                        "cost": col_texts[4] if len(col_texts) > 4 else "",
                        "upc": col_texts[5] if len(col_texts) > 5 else "",
                    }
                else:
                    continue
                
                # Only add if we have essential data
                if line_item["item_no"] and line_item["qty"]:
                    temp_items.append(line_item)
        
        # If we found items in this table, use them
        if temp_items:
            line_items = temp_items
            break

    # Populate Xoro template with data and defaults
    for idx, item in enumerate(line_items):
        # Core order data
        xoro_template.loc[idx, "CustomerName"] = metadata.get("xoro_customer_name", "")
        xoro_template.loc[idx, "OrderDate"] = metadata.get("order_date", "")
        xoro_template.loc[idx, "ItemCode"] = item["item_no"]
        xoro_template.loc[idx, "Quantity"] = item["qty"]
        xoro_template.loc[idx, "Description"] = item["description"]
        
        # Set default values as requested
        xoro_template.loc[idx, "StoreName"] = "IDI - Richmond"  # Store Number
        xoro_template.loc[idx, "CurrencyCode"] = "USD"
        xoro_template.loc[idx, "ExchangeRate"] = "1"
        
        # Leave Ship To Address fields blank
        xoro_template.loc[idx, "ShipToAddr"] = ""
        xoro_template.loc[idx, "ShipToAddr2"] = ""
        xoro_template.loc[idx, "ShipToCity"] = ""
        xoro_template.loc[idx, "ShipToState"] = ""
        xoro_template.loc[idx, "ShipToZpCode"] = ""
        xoro_template.loc[idx, "ShipToCountry"] = ""
        
        # Optional Ship To fields (may not exist in all templates)
        if "ShipToName" in xoro_template.columns:
            xoro_template.loc[idx, "ShipToName"] = ""
        if "ShipToCompanyName" in xoro_template.columns:
            xoro_template.loc[idx, "ShipToCompanyName"] = ""
        if "ShipToFirstName" in xoro_template.columns:
            xoro_template.loc[idx, "ShipToFirstName"] = ""
        if "ShipToLastName" in xoro_template.columns:
            xoro_template.loc[idx, "ShipToLastName"] = ""
        if "ShipToPhoneNumber" in xoro_template.columns:
            xoro_template.loc[idx, "ShipToPhoneNumber"] = ""
        if "ShipToEmail" in xoro_template.columns:
            xoro_template.loc[idx, "ShipToEmail"] = ""
            
        # Leave Customer Account Number blank
        xoro_template.loc[idx, "CustomerAccountNumber"] = ""

    return xoro_template

def extract_order_data_unfi_west(html_path, store_mapping_path=None):
    """
    Extract order data from UNFI West HTML files.
    Wrapper function to maintain consistency with other parsers.
    Returns standardized data structure like other UNFI parsers.
    
    Args:
        html_path: Path to the UNFI West HTML file
        store_mapping_path: Optional path to store mapping Excel file for customer name mapping
    """
    # Parse HTML file with better encoding handling - prioritize windows-1252
    content = None
    encodings_to_try = ['cp1252', 'windows-1252', 'latin-1', 'utf-8', 'iso-8859-1', 'utf-16']
    
    for encoding in encodings_to_try:
        try:
            with open(html_path, encoding=encoding) as f:
                content = f.read()
            break
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Error reading file with {encoding}: {e}")
            continue
    
    if content is None:
        print("Could not decode file with any supported encoding")
        return {"metadata": {}, "line_items": []}
    
    soup = BeautifulSoup(content, "html.parser")

    # Extract metadata
    metadata = {}
    
    # Extract order number from title first (most reliable for this format)
    if soup.title and soup.title.string:
        title_text = soup.title.string.strip()
        # Look for "Purchase Order XXXXXXX" pattern
        order_match = re.search(r'Purchase\s+Order\s+(\d+)', title_text, re.IGNORECASE)
        if order_match:
            metadata["order_number"] = order_match.group(1)
        else:
            # Fallback to any number in title
            order_match = re.search(r'(\d{6,})', title_text)
            if order_match:
                metadata["order_number"] = order_match.group(1)
    
    # Extract date from title (format: MM/DD/YY)
    if soup.title and soup.title.string:
        title_text = soup.title.string.strip()
        date_match = re.search(r'(\d{2}/\d{2}/\d{2,4})', title_text)
        if date_match:
            metadata["order_date"] = date_match.group(1)
    
    # Look for UNFI location information to determine customer name
    # Pattern: "UNFI - LOCATION, STATE" (e.g., "UNFI - ROCKLIN, CA")
    text_content = soup.get_text()
    lines = text_content.split('\n')
    
    customer_name = None
    for line in lines:
        line = line.strip()
        
        # Look for UNFI location pattern (more specific first)
        unfi_location_match = re.search(r'UNFI\s*-\s*([A-Z\s]+),\s*([A-Z]{2})', line, re.IGNORECASE)
        if unfi_location_match:
            location = unfi_location_match.group(1).strip().upper()
            state = unfi_location_match.group(2).strip().upper()
            customer_name = f"UNFI - {location}, {state}"
            metadata["customer_name"] = customer_name
            break
    
    # Fallback: look for any UNFI reference if specific pattern not found
    if not customer_name:
        customer_name_tag = soup.find(string=re.compile(r"UNFI.*West|West.*UNFI", re.IGNORECASE))
        if not customer_name_tag:
            # Fallback to general UNFI pattern
            customer_name_tag = soup.find(string=re.compile(r"UNFI", re.IGNORECASE))
        
        if customer_name_tag:
            metadata["customer_name"] = customer_name_tag.strip()

    # Extract order date from content if not found in title
    if not metadata.get("order_date"):
        order_date_tag = soup.find(string=re.compile(r"\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{2}"))
        if order_date_tag:
            # Extract just the date part
            date_match = re.search(r'(\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{2})', order_date_tag)
            if date_match:
                metadata["order_date"] = date_match.group(1)

    # Extract order number from content if not found in title
    if not metadata.get("order_number"):
        order_num_tag = soup.find(string=re.compile(r"Order.*#|PO.*#|Purchase.*Order|Order.*\d+"))
        if order_num_tag:
            # Extract order number using regex
            order_match = re.search(r'#?(\w+\d+|\d+)', order_num_tag)
            if order_match:
                metadata["order_number"] = order_match.group(1)

    # Extract line items - try multiple table structures
    line_items = []
    
    # Look for all tables
    tables = soup.find_all("table")
    
    for table in tables:
        rows = table.find_all("tr")
        if len(rows) < 2:  # Need at least header and one data row
            continue
        
        # Try to identify the data table by looking for headers
        header_row = rows[0]
        header_texts = [th.get_text(strip=True).lower() for th in header_row.find_all(["th", "td"])]
        
        # Look for typical order line headers
        expected_headers = ['item', 'qty', 'quantity', 'description', 'cost', 'price', 'upc', 'line', 'product']
        header_matches = sum(1 for header in header_texts if any(exp in header for exp in expected_headers))
        
        if header_matches >= 2:  # If we find at least 2 expected headers
            # This looks like our data table
            data_rows = rows[1:]  # Skip header row
            
            for row in data_rows:
                cols = row.find_all(["td", "th"])
                if len(cols) >= 3:  # Minimum columns for useful data
                    col_texts = [col.get_text(strip=True) for col in cols]
                    
                    # Skip empty rows
                    if not any(col_texts):
                        continue
                    
                    # Try to map columns based on content or position
                    line_item = {}
                    
                    # Basic mapping - adjust based on actual structure
                    if len(col_texts) >= 7:
                        line_item = {
                            "line": col_texts[0] if col_texts[0] else str(len(line_items) + 1),
                            "item_no": col_texts[1],
                            "qty": col_texts[2],
                            "description": col_texts[3],
                            "size": col_texts[4],
                            "cost": col_texts[5],
                            "upc": col_texts[6],
                        }
                    elif len(col_texts) >= 4:
                        # Minimal structure
                        line_item = {
                            "line": str(len(line_items) + 1),
                            "item_no": col_texts[0],
                            "qty": col_texts[1],
                            "description": col_texts[2],
                            "size": col_texts[3] if len(col_texts) > 3 else "",
                            "cost": col_texts[4] if len(col_texts) > 4 else "",
                            "upc": col_texts[5] if len(col_texts) > 5 else "",
                        }
                    
                    # Only add if we have essential data
                    if line_item and line_item.get("item_no") and line_item.get("qty"):
                        # Clean up the data
                        for key, value in line_item.items():
                            line_item[key] = str(value).strip() if value else ""
                        line_items.append(line_item)
            
            # If we found data in this table, break
            if line_items:
                break
    
    # If no structured table found, try to parse any table data
    if not line_items and tables:
        for table in tables:
            rows = table.find_all("tr")
            for row in rows:
                cols = row.find_all(["td", "th"])
                if len(cols) >= 3:
                    col_texts = [col.get_text(strip=True) for col in cols]
                    
                    # Skip empty rows
                    if not any(col_texts):
                        continue
                    
                    # Skip obvious header rows
                    if any(header in ' '.join(col_texts).lower() for header in ['item', 'qty', 'description', 'total', 'order']):
                        continue
                    
                    # Look for rows that have item-like data
                    if col_texts[0] and col_texts[1] and (col_texts[1].isdigit() or any(char.isdigit() for char in col_texts[1])):
                        line_item = {
                            "line": str(len(line_items) + 1),
                            "item_no": col_texts[0],
                            "qty": col_texts[1],
                            "description": col_texts[2] if len(col_texts) > 2 else "",
                            "size": col_texts[3] if len(col_texts) > 3 else "",
                            "cost": col_texts[4] if len(col_texts) > 4 else "",
                            "upc": col_texts[5] if len(col_texts) > 5 else "",
                        }
                        line_items.append(line_item)

    # Load store mapping if provided and map customer name
    if store_mapping_path:
        try:
            store_mapping = pd.read_excel(store_mapping_path)
            metadata["xoro_customer_name"] = map_unfi_customer_to_xoro(
                metadata.get("customer_name"), store_mapping
            )
        except Exception as e:
            print(f"Error loading store mapping: {e}")

    return {"metadata": metadata, "line_items": line_items}