from bs4 import BeautifulSoup
import re
import pandas as pd

def transform_unfi_east_order(html_path, store_mapping_path, template_path):
    """
    Transforms UNFI East order HTML file into Xoro sales order template.
    Returns a DataFrame representing the transformed order.
    """
    # Load store mapping
    store_mapping = pd.read_excel(store_mapping_path)

    # Load Xoro template
    xoro_template = pd.read_csv(template_path)

    # Parse HTML file
    with open(html_path, encoding="utf-8") as f:
        soup = BeautifulSoup(f, "html.parser")

    # Extract metadata
    metadata = {}
    
    # Look for UNFI East specific patterns
    customer_name_tag = soup.find(string=re.compile(r"UNFI.*East|East.*UNFI"))
    if not customer_name_tag:
        # Fallback to general UNFI pattern
        customer_name_tag = soup.find(string=re.compile(r"UNFI"))
    
    if customer_name_tag:
        metadata["customer_name"] = customer_name_tag.strip()

    # Extract order date - try multiple patterns
    order_date_tag = soup.find(string=re.compile(r"\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2}"))
    if order_date_tag:
        # Extract just the date part
        date_match = re.search(r'(\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2})', order_date_tag)
        if date_match:
            metadata["order_date"] = date_match.group(1)

    # Extract order number
    order_num_tag = soup.find(string=re.compile(r"Order.*#|PO.*#|Purchase.*Order"))
    if order_num_tag:
        # Extract order number using regex
        order_match = re.search(r'#?(\w+\d+|\d+)', order_num_tag)
        if order_match:
            metadata["order_number"] = order_match.group(1)

    # Map customer name using store_mapping
    if "customer_name" in metadata:
        xoro_customer_name = store_mapping.loc[
            store_mapping["UNFI Customer Name"] == metadata["customer_name"], 
            "Xoro Customer Name"
        ].values
        metadata["xoro_customer_name"] = xoro_customer_name[0] if len(xoro_customer_name) > 0 else "Unknown Customer"

    # Extract line items
    line_items = []
    
    # Try to find the main data table - look for common headers
    table = None
    for t in soup.find_all("table"):
        # Check if table has order line item structure
        headers = [th.get_text(strip=True).lower() for th in t.find_all("th")]
        header_text = " ".join(headers)
        
        # Look for common UNFI East table patterns
        if any(keyword in header_text for keyword in ['item', 'quantity', 'description', 'cost', 'upc']):
            table = t
            break
    
    if not table:
        # Fallback: look for largest table
        tables = soup.find_all("table")
        if tables:
            table = max(tables, key=lambda t: len(t.find_all("tr")))

    if table:
        rows = table.find_all("tr")
        # Skip header row(s)
        data_rows = rows[1:] if len(rows) > 1 else rows
        
        for row in data_rows:
            cols = row.find_all(["td", "th"])
            if len(cols) >= 4:  # Minimum columns for meaningful data
                # Extract text from each column
                col_texts = [col.get_text(strip=True) for col in cols]
                
                # Skip empty rows
                if all(not text for text in col_texts):
                    continue
                
                # Map columns based on typical UNFI East format
                line_item = {
                    "line": col_texts[0] if len(col_texts) > 0 else "",
                    "item_no": col_texts[1] if len(col_texts) > 1 else "",
                    "qty": col_texts[2] if len(col_texts) > 2 else "",
                    "description": col_texts[3] if len(col_texts) > 3 else "",
                    "size": col_texts[4] if len(col_texts) > 4 else "",
                    "cost": col_texts[5] if len(col_texts) > 5 else "",
                    "upc": col_texts[6] if len(col_texts) > 6 else "",
                }
                
                # Only add if we have essential data
                if line_item["item_no"] and line_item["qty"]:
                    line_items.append(line_item)

    # Return structured data for further processing
    return {
        "metadata": metadata,
        "line_items": line_items
    }

def extract_order_data_unfi_east(html_path):
    """
    Alternative function name for consistency with other parsers.
    Extracts order data from UNFI East HTML without requiring mapping files.
    """
    # Parse HTML file
    with open(html_path, encoding="utf-8") as f:
        soup = BeautifulSoup(f, "html.parser")

    # Extract metadata
    metadata = {}
    
    # Look for UNFI East specific patterns
    customer_name_tag = soup.find(string=re.compile(r"UNFI.*East|East.*UNFI"))
    if not customer_name_tag:
        customer_name_tag = soup.find(string=re.compile(r"UNFI"))
    
    if customer_name_tag:
        metadata["customer_name"] = customer_name_tag.strip()

    # Extract order date
    order_date_tag = soup.find(string=re.compile(r"\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2}"))
    if order_date_tag:
        date_match = re.search(r'(\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2})', order_date_tag)
        if date_match:
            metadata["order_date"] = date_match.group(1)

    # Extract order number
    order_num_tag = soup.find(string=re.compile(r"Order.*#|PO.*#|Purchase.*Order"))
    if order_num_tag:
        order_match = re.search(r'#?(\w+\d+|\d+)', order_num_tag)
        if order_match:
            metadata["order_number"] = order_match.group(1)

    # Extract line items
    line_items = []
    
    # Find the main data table
    table = None
    for t in soup.find_all("table"):
        headers = [th.get_text(strip=True).lower() for th in t.find_all("th")]
        header_text = " ".join(headers)
        
        if any(keyword in header_text for keyword in ['item', 'quantity', 'description', 'cost', 'upc']):
            table = t
            break
    
    if not table:
        tables = soup.find_all("table")
        if tables:
            table = max(tables, key=lambda t: len(t.find_all("tr")))

    if table:
        rows = table.find_all("tr")
        data_rows = rows[1:] if len(rows) > 1 else rows
        
        for row in data_rows:
            cols = row.find_all(["td", "th"])
            if len(cols) >= 4:
                col_texts = [col.get_text(strip=True) for col in cols]
                
                if all(not text for text in col_texts):
                    continue
                
                line_item = {
                    "line": col_texts[0] if len(col_texts) > 0 else "",
                    "item_no": col_texts[1] if len(col_texts) > 1 else "",
                    "qty": col_texts[2] if len(col_texts) > 2 else "",
                    "description": col_texts[3] if len(col_texts) > 3 else "",
                    "size": col_texts[4] if len(col_texts) > 4 else "",
                    "cost": col_texts[5] if len(col_texts) > 5 else "",
                    "upc": col_texts[6] if len(col_texts) > 6 else "",
                }
                
                if line_item["item_no"] and line_item["qty"]:
                    line_items.append(line_item)

    return {"metadata": metadata, "line_items": line_items}