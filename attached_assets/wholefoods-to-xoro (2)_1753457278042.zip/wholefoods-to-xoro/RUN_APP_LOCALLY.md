# 🚀 How to Run the UNFI Order Processor App Locally

## Quick Start Guide

### 1. **Open Terminal/Command Prompt**
Navigate to your project directory:
```bash
cd "c:\Users\risha\VS CODE PROJECTS\wholefoods-to-xoro"
```

### 2. **Start the Streamlit App**
Run one of these commands:

**Option A - Using Streamlit directly:**
```bash
streamlit run streamlit_app.py
```

**Option B - Using Python module:**
```bash
python -m streamlit run streamlit_app.py
```

**Option C - Specific port:**
```bash
streamlit run streamlit_app.py --server.port 8501
```

### 3. **Access the App**
The app will automatically open in your browser, or go to:
- **Local URL:** http://localhost:8501
- **Network URL:** http://192.168.x.x:8501 (for network access)

## 🧪 What You Can Test

### **Order Sources Available:**
- ✅ **Whole Foods** (HTML files)
- ✅ **UNFI West** (HTML files) 
- ✅ **UNFI East** (HTML files)
- ✅ **UNFI General** (CSV/Excel files)
- 🚧 **TK Maxx** (placeholder)

### **Test Files You Can Create:**

#### **UNFI West HTML Test File:**
```html
<html>
<body>
    <div>UNFI - West Coast Distribution</div>
    <div>Order Date: 12/15/2023</div>
    <div>Order #WC12345</div>
    <table>
        <tr>
            <th>Line</th><th>Item No.</th><th>Qty</th>
            <th>Description</th><th>Size</th><th>Cost</th><th>UPC</th>
        </tr>
        <tr>
            <td>1</td><td>12345</td><td>10</td>
            <td>Test Product</td><td>24/12oz</td>
            <td>$15.99</td><td>123456789012</td>
        </tr>
    </table>
</body>
</html>
```

#### **UNFI East HTML Test File:**
```html
<html>
<body>
    <div>UNFI East - Store #10001</div>
    <div>Order Date: 01/15/2024</div>
    <div>PO #EAST123</div>
    <table>
        <tr>
            <th>Line</th><th>Item</th><th>Quantity</th>
            <th>Description</th><th>Size</th><th>Cost</th><th>UPC</th>
        </tr>
        <tr>
            <td>1</td><td>54321</td><td>8</td>
            <td>East Product</td><td>6/32oz</td>
            <td>$18.75</td><td>111111111111</td>
        </tr>
    </table>
</body>
</html>
```

#### **UNFI General CSV Test File:**
```csv
Order Number,12345
Order Date,01/20/2024
Customer,UNFI General Customer

Line,Item,Quantity,Description,Cost,UPC
1,11111,15,General Product 1,$12.99,333333333333
2,22222,20,General Product 2,$8.75,444444444444
```

## 🎯 Testing Workflow

1. **Start the app** using the commands above
2. **Select order source** from the radio buttons
3. **Upload test file** (HTML/CSV/Excel)
4. **Download the generated Xoro CSV** 
5. **Verify the transformation** worked correctly

## 🔧 Troubleshooting

### **If Streamlit is not found:**
```bash
pip install streamlit
```

### **If dependencies are missing:**
```bash
pip install -r requirements.txt
```

### **If there are import errors:**
Make sure you're in the correct directory:
```bash
pwd  # Should show: /c/Users/risha/VS CODE PROJECTS/wholefoods-to-xoro
```

## 📊 What the App Does

1. **File Upload Interface** - Select order source and upload files
2. **Automatic Processing** - Parses orders using appropriate UNFI processor
3. **Mapping Application** - Maps items and stores using Excel mapping files
4. **Xoro CSV Generation** - Creates properly formatted Xoro import file
5. **Download Ready** - Provides download link for the transformed data

## ✅ Expected Results

- **Successful Upload** ✅
- **Data Extraction** ✅  
- **Item/Store Mapping** ✅
- **Xoro CSV Generation** ✅
- **Download Available** ✅

All UNFI processors (West, East, General) are fully implemented and tested!

---

**🚀 Ready to test! Your UNFI Order Processor is production-ready!**
