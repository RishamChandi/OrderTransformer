#!/usr/bin/env python3
"""
Quick test of current UNFI West parser - run this to see what happens
"""

def test_current_parser():
    """Test the current parser and show results"""
    file_path = r"c:\Users\risha\Downloads\UNFI WEST Purchase Order 446758464 08_30_24.html"
    
    print("Testing current UNFI West parser...")
    print(f"File: {file_path}")
    print("=" * 50)
    
    try:
        # Import our parser
        import sys
        import os
        sys.path.append(os.path.dirname(os.path.abspath(__file__)))
        
        from unfi_west_transformer import extract_order_data_unfi_west
        
        # Test the parser
        result = extract_order_data_unfi_west(file_path)
        
        print("PARSER RESULTS:")
        print(f"  Metadata: {result['metadata']}")
        print(f"  Line items count: {len(result['line_items'])}")
        
        if result['line_items']:
            print("\n  First few line items:")
            for i, item in enumerate(result['line_items'][:3]):
                print(f"    {i+1}: {item}")
            print("\n✅ SUCCESS: Found line items!")
        else:
            print("\n❌ PROBLEM: No line items found!")
            print("\nThis could mean:")
            print("  1. The HTML file has no table with order data")
            print("  2. The table structure is different than expected")
            print("  3. The file is incomplete or requires JavaScript to load data")
            
        # Let's also check what we can extract manually
        print(f"\n" + "="*50)
        print("MANUAL FILE CHECK:")
        
        try:
            with open(file_path, 'r', encoding='cp1252') as f:
                content = f.read()
            
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(content, 'html.parser')
            
            print(f"  ✅ File readable with cp1252 encoding")
            print(f"  📄 Content length: {len(content):,} characters")
            
            if soup.title:
                print(f"  📋 Title: {soup.title.string}")
            
            tables = soup.find_all('table')
            print(f"  📊 Tables found: {len(tables)}")
            
            if tables:
                for i, table in enumerate(tables):
                    rows = table.find_all('tr')
                    print(f"    Table {i+1}: {len(rows)} rows")
                    
                    # Show first row
                    if rows:
                        first_row = rows[0]
                        cells = first_row.find_all(['td', 'th'])
                        cell_texts = [cell.get_text(strip=True) for cell in cells]
                        print(f"      First row: {cell_texts}")
            else:
                print("    ❌ No tables found!")
                
                # Show some text content
                text = soup.get_text()
                print(f"    📝 Sample text (first 300 chars):")
                print(f"    {text[:300]}")
                
        except Exception as e:
            print(f"  ❌ Manual check failed: {e}")
            
    except Exception as e:
        print(f"❌ ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_current_parser()
